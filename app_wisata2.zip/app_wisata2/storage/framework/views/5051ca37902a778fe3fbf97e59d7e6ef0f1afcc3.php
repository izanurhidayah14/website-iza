<?php $__env->startSection('content'); ?>

<a href="<?php echo e(route('wisatas.create')); ?>" class="btn btn-primary" >Add New</a>
<table class="table">
    <tr>
        <th>Id</th>
        <th>Gambar</th>
        <th>Nama</th>
        <th>Kota</th>
        <th>Harga Tiket</th>
        <th>Aksi</th>
    </tr>

    <?php $__currentLoopData = $wisatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wisata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($wisata->id); ?></td>
        <td><img src="<?php echo e(Storage::url('public/images/' . $wisata->image)); ?>" alt="" style="width: 150px;"></td>
        <td><?php echo e($wisata->nama); ?></td>
        <td><?php echo e($wisata->kota); ?></td>
        <td><?php echo e($wisata->harga_tiket); ?></td>
        <td>
            <a href="<?php echo e(route('wisatas.show', $wisata->id)); ?>" class="btn btn-success" >Show</a>
            <a href="<?php echo e(route('wisatas.edit', $wisata->id)); ?>" class="btn btn-warning" >Edit</a>

            <form onclick="return confirm('Are you sure?')" action="<?php echo e(route('wisatas.destroy', $wisata->id)); ?>" 
            method="post"  style="display:inline;">
           <?php echo csrf_field(); ?>
           <?php echo method_field('DELETE'); ?>

            <button class="btn btn-danger" >Delete</button>
        </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php echo e($wisatas->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_wisata2/resources/views/wisatas/index.blade.php ENDPATH**/ ?>