@extends('wisatas.layout')

@section('content')
<form action="{{ route('wisatas.update', $wisata->id) }}" method="post"
enctype="multipart/form-data" class="form">
    
@csrf
@method('PUT')

<label for="">Nama</label><br>
<input type="text" name="nama" id="" value="{{ $wisata->nama }}"><br>

<label for="">Kota</label><br>
<input type="text" name="kota" id="" value="{{ $wisata->kota }}"><br>

<label for="">Harga Tiket</label><br>
<input type="text" name="harga_tiket" id="" value="{{ $wisata->harga_tiket }}"><br>

<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>

<input type="submit" value="Update" class="btn btn-info">
</form>
@endsection
