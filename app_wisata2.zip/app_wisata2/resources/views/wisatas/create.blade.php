@extends('wisatas.layout')

@section('content')
<form action="{{ route('wisatas.store')}}" method="post"
enctype="multipart/form-data" class="form">
    
@csrf

<label for="">Nama</label><br>
<input type="text" name="nama" id="" ><br>

<label for="">Kota</label><br>
<input type="text" name="kota" id="" ><br>

<label for="">Harga Tiket</label><br>
<input type="text" name="harga_tiket" id="" ><br>

<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>

<input type="submit" value="Save" class="btn btn-info">
</form>
@endsection
