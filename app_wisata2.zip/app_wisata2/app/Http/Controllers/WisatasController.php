<?php

namespace App\Http\Controllers;
use App\Models\Wisata;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;

class WisatasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $wisatas = Wisata::paginate(2);
        return view('wisatas.index',['wisatas'=>$wisatas]);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('wisatas.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $request->validate([
            'nama'=>'required',
            'kota'=>'required',
            'harga_tiket'=>'required',
            'image'=>'required|image|mimes:jpg,jpeg,png,svg,gif|max:2048'
        ]);

        $image = $request->file('image');
        $image->storeAs('public/images/', $image->hashName());

        
        Wisata::create([
            'nama'=> $request->nama,
            'kota'=> $request->kota,
            'harga_tiket'=> $request->harga_tiket,
            'image'=> $image->hashName(),
        ]);

        return redirect()->route('wisatas.index')->with('success','Wisata added successfully');
    }

        

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Wisata $wisata)
    {
        return view('wisatas.show',['wisata'=>$wisata]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Wisata $wisata)
    {
        return view('wisatas.edit',['wisata'=>$wisata]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Wisata $wisata)
    {
        $request->validate([
            'nama'=>'required',
            'kota'=>'required',
            'harga_tiket'=>'required',
            
        ]);

        if ($request->has('image')){
        $image = $request->file('image');
        $image->storeAs('public/images/', $image->hashName());

        Storage::delete('public/images/' .$wisata->image);
        
        $wisata->update([
            'nama'=> $request->nama,
            'kota'=> $request->kota,
            'harga_tiket'=> $request->harga_tiket,
            'image'=> $image->hashName(),
        ]);
    } else {
        $wisata->update([
            'nama'=> $request->nama,
            'kota'=> $request->kota,
            'harga_tiket'=> $request->harga_tiket,
        ]);
        }

        return redirect()->route('wisatas.index')->with('success','Wisata updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Wisata $wisata)
    {
        Storage::delete('public/images/' .$wisata->image);

        $wisata->delete();
        return redirect()->route('wisatas.index')->with('success','Wisata deleted successfully');

    }
}
